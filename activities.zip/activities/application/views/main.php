<div id="page-content">

	<div class="container">
		<div class="myslid">
							
    		<div id="slideshow">
				<div>
					<img src="<?php echo base_url(); ?>assets/images/slides/1.jpg">
				</div>
				<div>
					<img src="<?php echo base_url(); ?>assets/images/slides/2.jpg">
				</div>
				<div>
					<img src="<?php echo base_url(); ?>assets/images/slides/3.jpg">
				</div>
				<div>
					<img src="<?php echo base_url(); ?>assets/images/slides/4.jpg">
				</div>
				<div>
					<img src="<?php echo base_url(); ?>assets/images/slides/5.jpg">
				</div>
				<div>
					<img src="<?php echo base_url(); ?>assets/images/slides/6.jpg">
				</div>
				<div>
					<img src="<?php echo base_url(); ?>assets/images/slides/7.jpg">
				</div>
			</div>

		</div>
		<div class="side-message">
					
			<div class="widget sidebar-widget white-container" style=";padding:5px 5px;box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.2);">
							
				<style type="text/css">.alert{padding:13px 50px 13px 30px; margin-bottom: 0px;}</style>
				<div class="widget-content" >
								
					<div class="alert" style="background:#0072BC">
						<a href="http://www.aiub.edu" style="color:#fff;text-decoration:none;"><h6>AIUB</h6></a>
						
					</div>
					<div class="alert" style="background:green">
						<a href="http://portal.aiub.edu/" style="color:#fff;text-decoration:none;"><h6>PORTAL</h6></a>
						
					</div>
					<div class="alert alert-success">
						<a href="http://fsit.aiub.edu/" style="color:#fff;text-decoration:none;"><h6>FSIT</h6></a>
						
					</div>
					<div class="alert alert-info">
						<a href="http://research.cs.aiub.edu/" style="color:#fff;text-decoration:none;"><h6>RESEARCH</h6></a>
						
					</div>
					<div class="alert alert-warning">
						<a href="http://intern.cs.aiub.edu/" style="color:#fff;text-decoration:none;"><h6>INTERN</h6></a>
						
					</div>
					<div class="alert alert-error">
						<a href="http://alumni.cs.aiub.edu/" style="color:#fff;text-decoration:none;"><h6>ALUMNI</h6></a>
						
					</div>
								
								
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12 page-content">
				<div class="title-lines">
					<h3 class="mt0">NEWS & EVENTS</h3>
				</div>
				
					<?php
						foreach ($events as $key) {?>
							<a style="text-decoration:none;color:inherit;" href="<?php echo base_url(); ?>news-events/details/<?php echo $key['id'];?>">
							<div class="jobs-item with-thumb">
								
								<div class="clearfix visible-xs"></div>
								<div class="date <?php echo $key['tag'];?>"><?php echo $key['dd'];?> <span><?php echo $key['mm']; ?><font size="1px" style="display:block"><?php echo $key['yyyy'];?></font></span></div>
								<h3 class="title"><?php echo $key['title']; ?></h3>
								<span class="meta"><?php if($key['tag']=='acc'){echo "AIUB Computer Club";} 
									elseif($key['tag']=='student'){echo "Student Activities";}
									elseif($key['tag']=='faculty'){echo "Faculty Activities";}
									elseif($key['tag']=='seminar'){echo "Seminar";}
									elseif($key['tag']=='workshop'){echo "Workshop";}
									else {echo "Training";}
								?></span>
								<p class="description"><?php echo $key['short_details']; ?></p>
							</div>
							</a>

						<?php 	
							
							
							
						 	
						 	
						 	
						 } 

						 
					?>

				
					
						
						
						
						

						

						
						
				</div>	
			
		</div>
	</div>	
</div>
