<div id="page-content">
    <div class="container">
   <h1>Events</h1>
   <div class="table-responsive">
        <table class="table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Date</th>
                    <th>Tag</th>
                    <th>Title</th>
                    <th>Short Details</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
    <?php
            $serial = 1;
            foreach ($events as $key) {

                echo "<tr>";
                echo '<td>'.$serial.'</td>';
                echo '<td>'.$key['dd'].'';
                echo $key['mm'].',';
                echo $key['yyyy'].'</td>';
                echo '<td>'.$key['tag'].'</td>';
                echo '<td>'.$key['title'].'</td>';
                echo '<td>'.$key['short_details'].'</td>';
                echo "<td> <a href='".base_url()."event/edit/".$key['id']."'>Edit</a> |";
                echo "<a href='".base_url()."event/delete/".$key['id']."'>Delete</a></td>";
                echo "</tr>";
                $serial++;
             } 
             
?>          </tbody>
        </table>
        </div>
    </div>
</div>
 
                        
                            
                    
            