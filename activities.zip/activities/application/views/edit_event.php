 <body>
   <h1> Add Event</h1>
   
   <?php echo validation_errors(); ?>
   <?php echo form_open('events/verify'); ?>

     <input type="hidden" size="20" id="id" name="id" value="<?php echo $events[0]['id'];?>"/>
     <input type="hidden" size="20" id="dd" name="dd" value="<?php echo $events[0]['dd'];?>"/>
     <input type="hidden" size="20" id="mm" name="mm" value="<?php echo $events[0]['mm'];?>"/>
     <input type="hidden" size="20" id="yyyy" name="yyyy" value="<?php echo $events[0]['yyyy'];?>"/>

    
     <label for="title">Title:</label>
     <input type="text"  id="title" name="title" value="<?php echo $events[0]['title'];?>"/>
     <br/>
     <label for="shortdetails">Short Details:</label>
     <textarea type="text" size="50" id="shortdetails" name="shortdetails"> <?php echo $events[0]['short_details'];?> </textarea>
     <br/>
     <label for="tag">Tag</label>
     <select name="tag">
        <option value="acc" <?php if($events[0]['tag']=="acc") {echo "selected";} ?>>ACC</option>
        <option value="student" <?php if($events[0]['tag']=="student") {echo "selected";} ?>>Student Activities</option>
        <option value="faculty" <?php if($events[0]['tag']=="faculty") {echo "selected";} ?>>Faculty Activities</option>
        <option value="seminar" <?php if($events[0]['tag']=="seminar") {echo "selected";} ?>>Seminar</option>
        <option value="workshop" <?php if($events[0]['tag']=="workshop") {echo "selected";} ?>>Workshop</option>
        <option value="training" <?php if($events[0]['tag']=="training") {echo "selected";} ?>>Training</option>
     </select>
     <br/>
     <label for="access">Details:</label>
     <textarea id="summernote" name="details"><?php echo $events[0]['details'];?></textarea>
  <script>
    $(document).ready(function() {
        $('#summernote').summernote();
    });
  </script>
     <br/>
     <input type="submit" value="Submit"/>
   </form>
 </body>