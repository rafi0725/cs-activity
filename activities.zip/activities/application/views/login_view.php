<div class="container">
  <div style="display:table;margin:auto;width:40%;min-width:200px;background:#0072BC;margin-top:10px;margin-bottom:10px;padding:10px;border-radius:5px;color:#fff;box-shadow: 10px 10px 5px #888888;">
    
       <h1> Login </h1>
       
       <?php echo form_open('verifylogin'); ?>
         <label for="username">Username:</label>
         <input  type="text" size="20" id="username" name="username" style="color:#000;"/>
         <p class="error" id="chkuser" style="color:#fff"></p>
         <br/>
         <label for="password">Password:</label>
         <input type="password" size="20" id="password" name="password" style="color:#000;"/>
         <p class="error" id="chkpassword" style="color:#fff"></p>
         <br/>
         <?php echo validation_errors(); ?>
         <input type="submit" id="log_in" class="btn btn-default" value="Login"/>
       </form>
    
  </div>
</div>