

<div class="wrap">
      <br><br>
      <h1 style="font-size:5em;color:red;text-align:center;">Oops! Something wrong</h1>
      <div class="row center">
        <h5 style="font-size:4em;color:#006FB9;text-align:center;">404 Not Found</h5>
        <p style="font-size:1.5em;color:#006FB9;text-align:center;">Sorry, an error has occured! That requested page can’t be found. </p>
        <p style="font-size:1em;color:red;text-align:center;">It looks like nothing was found at this location. Maybe try one of the links below or a search? </p>
      </div>
      <div  >
        <br><br>
        <a href="<?php echo base_url(); ?>" style="background: #6C9BA9 none repeat scroll 0% 0%;display:table;margin:auto;padding: 8px 25px;font-size: 20px;color: #23272A;position: relative;transition: all 0.3s ease-in-out 0s;">Take Me Home</a>
      </div>
      <br><br>

</div>



