<div class="container">
	<div class="jobs-item with-thumb">
		<div class="clearfix visible-xs"></div>
		<div class="date <?php echo $details[0]['tag'];?>"><?php echo $details[0]['dd'];?> <span><?php echo $details[0]['mm']; ?><font size="1px" style="display:block"><?php echo $details[0]['yyyy'];?></font></span></div>
		<h3 class="title"><?php echo $details[0]['title']; ?></h3>
		<span class="meta">
			<?php if($details[0]['tag']=='acc'){echo "AIUB Computer Club";} 
					elseif($details[0]['tag']=='student'){echo "Student Activities";}
					elseif($details[0]['tag']=='faculty'){echo "Faculty Activities";}
					elseif($details[0]['tag']=='seminar'){echo "Seminar";}
					elseif($details[0]['tag']=='workshop'){echo "Workshop";}
					else {echo "Training";}
			?></span>
			<hr>
			<?php echo $details[0]['details']; ?>
			<hr>

			<div class="clearfix">
				

				<ul class="social-icons pull-right">
					<li><span>Share</span></li>
					<li><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo base_url(); ?>news-events/details/<?php echo $details[0]['id'];?>" class="btn btn-gray fa fa-facebook"></a></li>
					<li><a target="_blank" href="https://twitter.com/intent/tweet?url=<?php echo base_url(); ?>news-events/details/<?php echo $details[0]['id'];?>&text=<?php echo $details[0]['title']; ?>" class="btn btn-gray fa fa-twitter"></a></li>
					<li><a target="_blank" href="https://plus.google.com/share?url=<?php echo base_url(); ?>news-events/details/<?php echo $details[0]['id'];?>" class="btn btn-gray fa fa-google-plus"></a></li>
				</ul>
			</div>
	</div>

	

	
</div>

