<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<link rel="shortcut icon" href="<?php echo base_url();?>assets/img/aiub.png">
	<title><?php echo $head; ?> | Department of Computer Science - AIUB</title>
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css">
	<link href="<?php  echo base_url();?>assets/css/style.css" rel="stylesheet" type="text/css"/>
	<link rel="stylesheet" href="<?php echo  base_url();?>assets/css/responsive.css">
	<script type="text/javascript" src="<?php echo  base_url();?>assets/js/bootstrap.min.js"></script>

	<link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.css" rel="stylesheet">
	  <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.js"></script> 
	  <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.js"></script> 

	  <link href="<?php echo base_url();?>assets/dist/summernote.css" rel="stylesheet">
	  <script src="<?php echo base_url();?>assets/dist/summernote.js"></script>
	
</head>
<body>
	
		


<body>
<div id="main-wrapper">

	<header id="header" class="header-style-1">
		<div class="header-top-bar">
			<div class="container">

				<!-- Header Language -->
				<div class="header-language clearfix">
					<ul>
						<li class="active"><a href="<?php echo base_url();?>" >CS</a></li>
						<li><a href="http://www.aiub.edu" target="_blank">AIUB</a></li>
						<li><a href="http://portal.aiub.edu" target="_blank">PORTAL</a></li>
						<li><a href="http://research.cs.aiub.edu" target="_blank">RESEARCH</a></li>
						<li><a href="http://intern.cs.aiub.edu" target="_blank">INTERN</a></li>
						<li><a href="http://alumni.cs.aiub.edu" target="_blank">ALUMNI</a></li>
						
					</ul>
				</div> <!-- end .header-language -->
				

				
				
				
				<!--<a href="http://portal.aiub.edu" class="btn btn-link links-new" target="_blank">AIUB PORTAL</a>
				<a href="http://www.aiub.edu" class="btn btn-link links-new" target="_blank">AIUB</a>-->
			</div> <!-- end .container -->
		</div> <!-- end .header-top-bar -->
		<div class="container" style="margin-bottom:5px;">
				
				<div class="css-table aiub-logo">
					<a href="<?php echo base_url();?>" target="_blank">
					<div style="float:left">
						
							<img src="<?php echo base_url();?>assets/img/aiub.png" alt="" width="100px" height="96px">

						 <!-- end .logo -->
					</div>
					<div style="float:left;margin-left:10px;">
						<p style="position: absolute;color: #004EA8;font-family: 'segoe UI';font-weight: 700;font-size: 15px;line-height: 17px;margin: 5px 0px 0px 0px;">
							AMERICAN <br>INTERNATIONAL<br>UNIVERSITY-<br>BANGLADESH</h1>
                            
						</p>
						<p style="position: absolute;font-size: 0.80em;text-align: center;font-family: 'Signika',sans-serif;text-transform: lowercase;color: #000;font-weight: 500;margin: 75px 5px 5px 0px;line-height:1.1;">where leaders are created</p>
					</div>
					</a>
					<div class="clearfix"></div>
				</div>
				<div class="css-table cs-logo">
					
					<div style="float:right">
						<form action="<?php echo base_url(); ?>main/search" method="post">
							<div class="input-group">
						        <input name="search" id="key" class="form-control" style="height:34px" placeholder="Search" value="" type="text">
						        <span class="input-group-btn">
						            <button class="btn btn-theme" type="submit" style="background: #0072BC none repeat scroll 0% 0%;">&nbsp;<span class="glyphicon glyphicon-search"></span>&nbsp;</button>
						        </span>
						        </form>
						    </div>
							<p style="text-align:center;color: #0072BC;font-family: 'segoe UI';font-weight: 700;font-size: 20px;line-height: 17px;margin: 10px 0px 0px 0px;">
							Department Of Computer Science <br> <br>Activity Site
							
						</p>

						<!-- end .logo -->
					</div>
					<div style="float:right;margin-right:10px;">
						
						
					</div>
					
					<div class="clearfix"></div>
				</div>
		</div>
		<div class="header-nav-bar">
			<div class="container">

				<!-- Logo -->
				

				<!-- Mobile Menu Toggle -->
				<a href="#" id="mobile-menu-toggle"><span></span></a>

				<!-- Primary Nav -->
				<nav>
					<ul class="primary-nav">
						
						
						<?php if($this->session->userdata('logged_in'))
					   {
					     $session_data = $this->session->userdata('logged_in');
					     ?>
						

						<li><a href="<?php echo base_url();?>dashboard">Dashboard</a></li>
						<li><a href="<?php echo base_url();?>events">Event List</a></li>
						<li><a href="<?php echo base_url();?>addevent">Add Event</a></li>
						<li><a href="<?php echo base_url();?>changepass">Change Password</a></li>
						<?php if($session_data['access'] == "admin"){?>
						<li><a href="<?php echo base_url();?>createuser">Create User</a></li>
						<?php }?>
						<li><a href="<?php echo base_url();?>dashboard/logout">Logout</a></li>
					<?php }else{?>
						<li><a href="<?php echo base_url();?>">Home</a></li>
						<li><a href="<?php echo base_url();?>category/acc">ACC</a></li>
						<li><a href="<?php echo base_url();?>category/student">Student Activities</a></li>
						<li><a href="<?php echo base_url();?>category/faculty">Faculty Activities</a></li>
						<li><a href="<?php echo base_url();?>category/seminar">Seminar</a></li>
						<li><a href="<?php echo base_url();?>category/workshop">Workshop</a></li>
						<li><a href="<?php echo base_url();?>category/training">Training</a></li>

					<?php }?>

					</ul>
					
				</nav>
			</div> <!-- end .container -->

			<div id="mobile-menu-container" class="container">
				<div class="login-register"></div>
				<div class="menu"></div>
			</div>
		</div> <!-- end .header-nav-bar -->
	</header> <!-- end #header -->
