</body>
<footer id="footer">
		<div class="container">
			<div class="row">
				<div class="col-sm-3 col-md-4">
					<div class="widget">
						<div class="widget-content">
							<h4 style="text-align:center;color:#fff;">Quick Search</h4>
							<p style="text-align:center;">
								
								<a href="<?php echo base_url();?>main/quickSearch/CS-Fest-2015" style="font-size:20px;">CS Fest 2015</a>
								<a href="<?php echo base_url();?>main/quickSearch/Big-Data" style="font-size:20px;">Big Data</a>
								<a href="<?php echo base_url();?>main/quickSearch/Workshop" style="font-size:12px;">Workshop</a>
								<a href="<?php echo base_url();?>main/quickSearch/Champion" style="font-size:20px;">Champion</a>
								<a href="<?php echo base_url();?>main/quickSearch/Winners" style="font-size:12px;">Winners</a>
								<a href="<?php echo base_url();?>main/quickSearch/CS-Fest-2014" style="font-size:20px;">CS Fest 2014</a>
								<a href="<?php echo base_url();?>main/quickSearch/Programming-Contest" style="font-size:12px;">Programming Contest</a>
								<a href="<?php echo base_url();?>main/quickSearch/App-Concept" style="font-size:20px;">App Concept</a>
								<a href="<?php echo base_url();?>main/quickSearch/Mozilla" style="font-size:12px;">Mozilla</a>
								<a href="<?php echo base_url();?>main/quickSearch/Research" style="font-size:20px;">Research</a>
								<a href="<?php echo base_url();?>main/quickSearch/Microsoft" style="font-size:12px;">Microsoft</a>
								<a href="<?php echo base_url();?>main/quickSearch/Orientation" style="font-size:20px;">Orientation</a>
								<a href="<?php echo base_url();?>main/quickSearch/Cisco" style="font-size:12px;">Cisco</a>
								<a href="<?php echo base_url();?>main/quickSearch/CS-Festival" style="font-size:20px;">CS Fest 2013</a>
								<a href="<?php echo base_url();?>main/quickSearch/Welcome-Fresher" style="font-size:12px;">Welcome Fresher</a>
								<a href="<?php echo base_url();?>main/quickSearch/ACC" style="font-size:20px;">ACC</a>
								<a href="<?php echo base_url();?>main/quickSearch/Seminar" style="font-size:12px;">Seminar</a>
								<a href="<?php echo base_url();?>main/quickSearch/Recruitment" style="font-size:20px;">Recruitment</a>
								<a href="<?php echo base_url();?>main/quickSearch/AIUB-Computer-Club" style="font-size:12px;">AIUB Computer Club</a>
								<a href="<?php echo base_url();?>main/quickSearch/CS-Festival" style="font-size:20px;">CS Fest 2012</a>
							</p>
						</div>
					</div>
				</div>

				<div class="col-sm-3 col-md-4" style="background: rgba(58, 63, 73, 0.6) none repeat scroll 0% 0%;">
					<a href="<?php echo base_url();?>">
					<img src="<?php echo base_url();?>assets/img/aiub.png" alt="" width="100px" height="96px" style="display:table;margin:auto; margin-top:5px;"></a>
					<p style="text-align:center;margin-top:5px;"><em>Founded in 1994</em></p>
					<hr style="width: 60px;margin: 5px auto;border:1px solid #666 transparent transparent">
					<p style="text-align:center;color:#fff;font-size:13px;">American International University-Bangladesh (AIUB)</p>
					<P style="text-align:center;color:#999;">
						<span class="glyphicon glyphicon-map-marker"></span> 
						House-55/B,Road-21, Block-B Kemal Ataturk Avenue, 
						<br>Banani,Dhaka 1213, Bangladesh<br>
                         <span class="glyphicon glyphicon-phone-alt"></span>
                          +88-02-55034165, +88-02-55034232 
                          <br>
                           <span class="glyphicon glyphicon-envelope"></span> info@aiub.edu </P>
				</div>

				<div class="col-sm-3 col-md-2" style="margin-top:30px;color:#fff;">
					<div class="widget">
						<h6 class="widget-title">Site links</h6>

						<div class="widget-content">
							<ul class="footer-links">
								<li><a href="<?php echo base_url();?>">HOME</a></li>
								<li><a href="<?php echo base_url();?>category/acc">ACC</a></li>
								<li><a href="<?php echo base_url();?>category/student">STUDENT ACTIVITIES</a></li>
								<li><a href="<?php echo base_url();?>category/faculty">FACULTY ACTIVITIES</a></li>
								<li><a href="<?php echo base_url();?>category/seminar">SEMINAR</a></li>
								
								
							</ul>
						</div>
					</div>
				</div>

				<div class="col-sm-3 col-md-2" style="margin-top:55px;color:#fff;">
					<div class="widget">
						

						<div class="widget-content">
							<ul class="footer-links">
								<li><a href="<?php echo base_url();?>category/workshop">WORKSHOP</a></li>
								<li><a href="<?php echo base_url();?>category/training">TRAINING</a></li>
								
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="copyright">
			<div class="container">
				<p>2012-<?php echo date("Y");?> &copy; <a href="http://www.aiub.edu/" target="_blank">American International University-Bangladesh</a> under registration 9988-COPR</p>

				<ul class="footer-social">
					Developed by <a href="http://hasibulhuq.com/" target="_blank">Md.Hasibul Huq</a>
					
					 
					
				</ul>
			</div>
		</div>
	</footer> <!-- end #footer -->
<script src="<?php echo base_url();?>assets/js/jquery.inview.min.js"></script>
<script src="<?php echo base_url();?>assets/js/script.js"></script>
<script>
$( "#log_in" ).click(function(event) {
  if($('#username').val().length==0){
        $('#chkuser').html('Please Enter your AIUB Student ID!');
        event.preventDefault();
      }else if($('#username').val().length!=5 && $('#username').val().length!=10){
        $('#chkuser').html('Your AIUB ID usually looks like XX-XXXXX-X or XXXX-XXX-X');
        event.preventDefault();
      }
      
      
      else $('#chkuser').html('');

        if($('#password').val().length==0){
        $('#chkpassword').html('Please Enter your ACC password!');
        event.preventDefault();
      }else $('#chkpassword').html('');
        
});

$( "#changepass" ).click(function(event) {
  if($('#old').val().length==0){
        $('#chkold').html('Please enter your current password');
        event.preventDefault();
      }
      else $('#chkold').html('');

        if($('#new').val().length==0){
        $('#chknew').html('Please enter your new password');
        event.preventDefault();
      }else $('#chknew').html('');

      if($('#retype').val().length==0){
        $('#chkretype').html('Please enter your new password again');
        event.preventDefault();
      }else if ($('#retype').val() != $('#new').val()){
      	$('#chkretype').html('Not matching with new password');
        event.preventDefault();
      }
      else $('#chknew').html('');
        
});
</script>