<div id="page-content">
    <div class="container">
        <div style="display:table;margin:auto;width:40%;min-width:200px;background:#0072BC;margin-top:10px;margin-bottom:10px;padding:10px;border-radius:5px;color:#fff;box-shadow: 10px 10px 5px #888888;">
   
               <h1> Create User</h1>
               
               <?php echo validation_errors(); ?>
               <?php echo form_open('createuser/verify'); ?>
                 <label for="name">Name:</label>
                 <input type="text" size="20" id="name" name="name" style="color:#000;"/>
                 <br/>
                 <label for="username">User Name:</label>
                 <input type="text" size="20" id="username" name="username" style="color:#000;"/>
                 <br/>
                 <label for="email">email:</label>
                 <input type="email" size="20" id="email" name="email" style="color:#000;"/>
                 <br/>
                 <label for="password">Password:</label>
                 <input type="password" size="20" id="password" name="password" style="color:#000;"/>
                 <br/>
                 <label for="access">Access:</label>
                 <select name="access" style="color:#000;">
                    <option value="admin">Admin</option>
                    <option value="editor">Editor</option>
                 </select>
                 <br/>
                 <input type="submit"  class="btn btn-default" value="Create"/>
         </form>
       </div>

        <div class="table-responsive">
            <table class="table-bordered">
                <thead>
                     <tr>
                        <th>ID</th>
                         <th>User Name</th>
                         <th>Access</th>
                         <th>Full Name</th>
                         <th>Email</th>
                         <th>Action</th>
                     </tr>
                </thead>

                <tbody>
   <?php
            foreach ($users as $key) {
                echo "<tr>";
                echo '<td>'.$key['id'].'</td>';
                echo '<td>'.$key['user_name'].'</td>';
                echo '<td>'.$key['access'].'</td>';
                echo '<td>'.$key['name'].'</td>';
                echo '<td>'.$key['email'].'</td>';
                echo "<td><a href='".base_url()."createuser/delete/".$key['id']."'>Delete</a></td>";
                echo '<tr>';
             } 

             
        ?>
                </tbody>
             </table>
        </div>
    </div>
</div>