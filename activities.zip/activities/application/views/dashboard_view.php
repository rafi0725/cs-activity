<div id="page-content">
		<div class="container">
			<div class="row">
				<div class="col-sm-4 page-sidebar">
					<aside>
						<div class="widget sidebar-widget white-container candidates-single-widget">
							<div class="widget-content">
								

								<h5 class="bottom-line">User Details</h5>

								<table>
									<tbody>
										<tr>
											<td>Name</td>
											<td><?php echo $name; ?></td>
										</tr>

										<tr>
											<td>Email</td>
											<td><a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a></td>
										</tr>

										<tr>
											<td>User Name</td>
											<td><?php echo $username; ?></td>
										</tr>

										
									</tbody>
								</table>

								

								
							</div>
						</div>
					</aside>
				</div> <!-- end .page-sidebar -->

				<div class="col-sm-8 page-content">
					

					<div class="candidates-item candidates-single-item">
						 <h2>Welcome <?php echo $username; ?>!</h2>
						<span class="meta"><?php echo $name; ?></span>

						<hr>

						
						<div class="row">
							<div class="col-md-4">
								<a href="<?php echo base_url();?>events" class="btn btn-red" style="width:100%;height:100px;padding-top:30px;font-size:20px;">Event List</a>
							</div>
							<div class="col-md-4">
								<a href="<?php echo base_url();?>addevent" class="btn btn-gray" style="width:100%;height:100px;padding-top:30px;font-size:20px;">Add Event</a>
							</div>
							<div class="col-md-4">
								<a href="<?php echo base_url();?>changepass" class="btn btn-blue" style="width:100%;height:100px;padding-top:30px;font-size:20px;">Change Password</a>
							</div>
						</div>

						

						

						

						
					</div>

					

					

					

					
				</div> <!-- end .page-content -->
			</div>
		</div> <!-- end .container -->
	</div> <!-- end #page-content -->