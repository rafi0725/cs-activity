<div id="page-content">
    <div class="container">
        <div style="display:table;margin:auto;width:40%;min-width:200px;background:#0072BC;margin-top:10px;margin-bottom:10px;padding:10px;border-radius:5px;color:#fff;box-shadow: 10px 10px 5px #888888;">
   
         <h1> Change Password</h1>
         
         <?php echo validation_errors(); ?>
         <?php echo form_open('changepass/verify'); ?>
           <label for="old">Password:</label>
           <input type="password" size="20" id="old" name="password" style="color:#000;"/>
            <p class="error" id="chkold" style="color:#fff"></p>
           <br/>
           <label for="new">New Password:</label>
           <input type="password" size="20" id="new" name="newpassword" style="color:#000;"/>
           <p class="error" id="chknew" style="color:#fff"></p>
           <br/>
           <label for="retype">Retype Password:</label>
           <input type="password" size="20" id="retype" name="repassword" style="color:#000;"/>
           <p class="error" id="chkretype" style="color:#fff"></p>
           <br/>
           <input type="submit" id="changepass" class="btn btn-default" value="Change"/>
         </form>
       </div>
  </div>
</div>