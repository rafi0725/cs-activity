<div id="page-content">
        <div class="container">
   <h1> Add Event</h1>
   
   <?php echo validation_errors(); ?>
   <?php echo form_open('addevent/verify'); ?>
     
     <input type="hidden" size="20" id="dd" name="dd" value="<?php echo date('d');?>"/>
     <input type="hidden" size="20" id="mm" name="mm" value="<?php echo date('M');?>"/>
     <input type="hidden" size="20" id="yyyy" name="yyyy" value="<?php echo date('Y');?>"/>

    
     <label for="title">Title:</label>
     <input type="text"  id="title" name="title"/>
     <br/>
     <label for="shortdetails">Short Details:</label>
     <textarea type="text" size="50" id="shortdetails" name="shortdetails"> </textarea>
     <br/>
     <label for="tag">Tag</label>
     <select name="tag">
        <option value="acc">ACC</option>
        <option value="student">Student Activities</option>
        <option value="faculty">Faculty Activities</option>
        <option value="seminar">Seminar</option>
        <option value="workshop">Workshop</option>
        <option value="training">Training</option>
     </select>
     <br/>
     <label for="access">Details:</label>
     <textarea id="summernote" name="details"></textarea>
  <script>
    $(document).ready(function() {
        $('#summernote').summernote();
    });
  </script>
     <br/>
     <input type="submit" class="btn btn-red" value="Add Event"/>
   </form>
   <br>
    </div>
</div>