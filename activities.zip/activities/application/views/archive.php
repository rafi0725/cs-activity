

<div class="container">
	<h1>News & Events</h1>

	<div id="body">
		<?php
			foreach ($events as $key) {?>
						<a style="text-decoration:none;color:inherit;" href="<?php echo base_url(); ?>news-events/details/<?php echo $key['id'];?>">
							<div class="jobs-item with-thumb">
								
								<div class="clearfix visible-xs"></div>
								<div class="date <?php echo $key['tag'];?>"><?php echo $key['dd'];?> <span><?php echo $key['mm']; ?><font size="1px" style="display:block"><?php echo $key['yyyy'];?></font></span></div>
								<h3 class="title"><?php echo $key['title']; ?></h3>
								<span class="meta"><?php if($key['tag']=='acc'){echo "AIUB Computer Club";} 
									elseif($key['tag']=='student'){echo "Student Activities";}
									elseif($key['tag']=='faculty'){echo "Faculty Activities";}
									elseif($key['tag']=='seminar'){echo "Seminar";}
									elseif($key['tag']=='workshop'){echo "Workshop";}
									else {echo "Training";}
								?></span>
								<p class="description"><?php echo $key['short_details']; ?></p>
							</div>
						</a>
			<?php } 

			 
		?>
						<ul class="pagination pull-right">
							<?php $back= $page -1;
								$next = $page+1;
								if($page!=-1){
							?>
							<li><a href="<?php echo base_url(); ?>category/<?php echo $tag.'/'.$back; ?>" class="fa fa-angle-left"></a></li>
							<?php }for ($i=1; $i < $pages+1 ; $i++) { 
							 ?>

							 
							<li <?php if($page == $i){ echo 'class="active"';} ?>><a href="<?php echo base_url(); ?>category/<?php echo $tag.'/'.$i; ?>"><?php echo $i; ?></a></li>
							
							
							 <?php }if($page!=-1){?>
							<li><a href="<?php echo base_url(); ?>category/<?php echo $tag.'/'.$next; ?>" class="fa fa-angle-right"></a></li><?php }?>
						</ul>

	</div>

	
</div>

