<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
session_start(); //we need to call PHP's session object to access it through CI
class Createuser extends CI_Controller {
 
 function __construct()
 {
   parent::__construct();
 }
 
 function index()
 {
   if($this->session->userdata('logged_in'))
   {
     $this->load->helper(array('form'));
     $session_data = $this->session->userdata('logged_in');
     $data['access'] = $session_data['access'];
     if($data['access']=='admin')
     {
      $data['username'] = $session_data['username'];
       $this->load->model('User_model');
      $data['users'] = $this->User_model->userslist();
      $title['head'] = 'Create User';
      $this->load->view('include/header', $title);
      $this->load->view('createuser', $data);
      $this->load->view('include/footer');
     }
     else
     {
       //If no session, redirect to login page
       redirect('dashboard', 'refresh');
     }
   }
   else
   {
     //If no session, redirect to login page
     redirect('login', 'refresh');
   }
 }
 function verify()
 {
   $this->load->library('form_validation');
 
   
   $this->form_validation->set_rules('name', 'Name', 'trim|required|xss_clean|callback_check_database');
   $this->form_validation->set_rules('username', 'User Name', 'trim|required|xss_clean');
   $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
   $this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean');

   if($this->form_validation->run() == FALSE)
   {
     //Field validation failed.  User redirected to login page
     $title['head'] = 'Create User';
     $session_data = $this->session->userdata('logged_in');
     $data['username'] = $session_data['username'];
     $this->load->view('include/header', $title);
     $this->load->view('createuser',$data);
     $this->load->view('include/footer');
   }
   else
   {
     //Go to private area
    redirect('createuser', 'refresh');
   }
 }
 
 function check_database($password)
 {
   $this->load->model('User_model','',TRUE);
   //Field validation succeeded.  Validate against database
    $name = $this->input->post('name');
    $username = $this->input->post('username');
    $email = $this->input->post('email');
    $password = $this->input->post('password');
    $access = $this->input->post('access');
   //query the database
   $result = $this->User_model->validuser($username);
 
   if($result)
   {
     
     $this->form_validation->set_message('check_database', 'Invalid  password');
     return false;
   }
   else
   {
     $this->User_model->createnewuser($name, $username, $email, $password, $access);
     
     return TRUE;
   }
 }
 function delete($id)
 {
    
      $this->load->model('User_model');
      $this->User_model->delete($id);
      redirect('createuser', 'refresh');
 }
 
}
 
?>