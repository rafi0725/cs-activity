<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
session_start(); //we need to call PHP's session object to access it through CI
class Addevent extends CI_Controller {
 
 function __construct()
 {
   parent::__construct();
 }
 
 function index()
 {
   if($this->session->userdata('logged_in'))
   {
     $this->load->helper(array('form'));
     $session_data = $this->session->userdata('logged_in');
     
      $data['username'] = $session_data['username'];
      $title['head'] = 'Add Event';
      $this->load->view('include/header', $title);
      $this->load->view('addevent', $data);
      $this->load->view('include/footer');
     
   }
   else
   {
     //If no session, redirect to login page
     redirect('login', 'refresh');
   }
 }
 function verify()
 {
   $this->load->library('form_validation');
   var_dump($_POST['title']);
   var_dump($_POST['shortdetails']);
   var_dump($_POST['details']);
   
     $this->form_validation->set_rules('title', 'Title', 'trim|required|');
   $this->form_validation->set_rules('shortdetails', 'Short Details', 'trim|required');

   if($this->form_validation->run() == FALSE)
   {
     //Field validation failed.  User redirected to login page
     $title['head'] = 'Add Event';
     $session_data = $this->session->userdata('logged_in');
     $data['username'] = $session_data['username'];
     $this->load->view('include/header', $title);
     $this->load->view('addevent',$data);
     $this->load->view('include/footer');
     
     
   }
   else if($this->form_validation->run() == TRUE)
   {
    $this->load->model('Event_model','',TRUE);
   //Field validation succeeded.  Validate against database
    $title = $this->input->post('title');
    $shortdetails = $this->input->post('shortdetails');
    $tag = $this->input->post('tag');
    $dd = $this->input->post('dd');
    $mm = $this->input->post('mm');
    $yyyy = $this->input->post('yyyy');
    $details = $this->input->post('details');
   //query the database
   
 
   
 
     $this->Event_model->addevent($title, $shortdetails, $tag, $dd, $mm, $yyyy, $details );
      redirect('events', 'refresh'); 
     

   }
   else
   {
     //Go to private area
    redirect('events', 'refresh');
   }
 }
 
 function check_database($title)
 {
   //hello
  return TRUE;
  
 }
 
}
 
?>