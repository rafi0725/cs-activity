<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Category extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index($page)
	{	
		if($page<1){$page=1;}
		$title['head'] = 'All Events';
		$this->load->model('Category_model');
		$query = $this->Category_model->all($page);
		$data['events'] = $query['result'];
		$data['pages'] = $query['pages'];
		$data['tag'] = 'all';
		$data['page']= $page;
		$this->load->view('include/header', $title);
		$this->load->view('archive', $data);
		$this->load->view('include/footer');
	}
	public function acc($page)
	{	
		if($page<1){$page=1;}
		$title['head'] = 'ACC\'s Events';
		$this->load->model('Category_model');
		$query = $this->Category_model->acc($page);
		$data['events'] = $query['result'];
		$data['pages'] = $query['pages'];
		$data['tag'] = 'acc';
		$data['page']= $page;
		$this->load->view('include/header', $title);
		$this->load->view('archive', $data);
		$this->load->view('include/footer');
	}
	public function student($page)
	{	
		if($page<1){$page=1;}
		$title['head'] = 'Student Activities';
		$this->load->model('Category_model');
		$query = $this->Category_model->student($page);
		$data['events'] = $query['result'];
		$data['pages'] = $query['pages'];
		$data['tag'] = 'student';
		$data['page']= $page;
		$this->load->view('include/header', $title);
		$this->load->view('archive', $data);
		$this->load->view('include/footer');
	}
	public function faculty($page)
	{	
		if($page<1){$page=1;}
		$title['head'] = 'Faculty Activities';
		$this->load->model('Category_model');
		$query = $this->Category_model->faculty($page);
		$data['events'] = $query['result'];
		$data['pages'] = $query['pages'];
		$data['tag'] = 'faculty';
		$data['page']= $page;
		$this->load->view('include/header', $title);
		$this->load->view('archive', $data);
		$this->load->view('include/footer');
	}
	public function seminar($page)
	{	
		if($page<1){$page=1;}
		$title['head'] = 'Seminar';
		$this->load->model('Category_model');
		$query = $this->Category_model->seminar($page);
		$data['events'] = $query['result'];
		$data['pages'] = $query['pages'];
		$data['tag'] = 'seminar';
		$data['page']= $page;
		$this->load->view('include/header', $title);
		$this->load->view('archive', $data);
		$this->load->view('include/footer');
	}
	public function workshop($page)
	{	
		if($page<1){$page=1;}
		$title['head'] = 'Workshop';
		$this->load->model('Category_model');
		$query = $this->Category_model->workshop($page);
		$data['events'] = $query['result'];
		$data['pages'] = $query['pages'];
		$data['tag'] = 'workshop';
		$data['page']= $page;
		$this->load->view('include/header', $title);
		$this->load->view('archive', $data);
		$this->load->view('include/footer');
	}
	public function training($page)
	{	
		if($page<1){$page=1;}
		$title['head'] = 'Training';
		$this->load->model('Category_model');
		$query = $this->Category_model->training($page);
		$data['events'] = $query['result'];
		$data['pages'] = $query['pages'];
		$data['tag'] = 'training';
		$data['page']= $page;
		$this->load->view('include/header', $title);
		$this->load->view('archive', $data);
		$this->load->view('include/footer');
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */