<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
session_start(); //we need to call PHP's session object to access it through CI
class Changepass extends CI_Controller {
 
 function __construct()
 {
   parent::__construct();
 }
 
 function index()
 {
   if($this->session->userdata('logged_in'))
   {
     $this->load->helper(array('form'));
     $session_data = $this->session->userdata('logged_in');
     $data['username'] = $session_data['username'];
     $title['head'] = 'Change Password';
     $this->load->view('include/header', $title);
     $this->load->view('changepas', $data);
     $this->load->view('include/footer');
   }
   else
   {
     //If no session, redirect to login page
     redirect('login', 'refresh');
   }
 }
 function verify()
 {
   $this->load->library('form_validation');
 
   
   $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean|callback_check_database');
   $this->form_validation->set_rules('newpassword', 'New Password', 'trim|required|xss_clean');
   $this->form_validation->set_rules('repassword', 'Retype Password', 'trim|required|xss_clean');

   if($this->form_validation->run() == FALSE)
   {
     //Field validation failed.  User redirected to login page
     $title['head'] = 'Change Password';
     //$data['username'] = $session_data['username'];
     $this->load->view('include/header', $title);
     $this->load->view('changepas');
     $this->load->view('include/footer');
   }
   else
   {
     //Go to private area
    redirect('dashboard', 'refresh');
   }
 }
 
 function check_database($password)
 {
   $this->load->model('User_model','',TRUE);
   //Field validation succeeded.  Validate against database
   $session_data = $this->session->userdata('logged_in');
   $username = $session_data['username'];
    $newpassword = $this->input->post('newpassword');
   //query the database
   $result = $this->User_model->login($username, $password);
 
   if($result)
   {
     $this->User_model->changepass($username, $newpassword);
     
     return TRUE;
   }
   else
   {
     $this->form_validation->set_message('check_database', 'Invalid  password');
     return false;
   }
 }
 
}
 
?>