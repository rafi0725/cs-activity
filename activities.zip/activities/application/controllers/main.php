<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Main extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{	
		$title['head'] = 'Home';
		$this->load->model('Main_model');
		$data['events'] = $this->Main_model->ten();
		$this->load->view('include/header', $title);
		$this->load->view('main', $data);
		$this->load->view('include/footer');
	}
	public function search()
	{	
		$this->load->library('form_validation');
 
   		$this->form_validation->set_rules('search', 'Search', 'trim|xss_clean');
   		$search = $this->input->post('search');
		$title['head'] = 'Search Result';
		$this->load->model('Main_model');
		$data['events'] = $this->Main_model->search($search);
		$data['pages'] = 0;
		$data['tag'] = 'all';
		$data['page'] = -1;
		$this->load->view('include/header', $title);
		$this->load->view('archive', $data);
		$this->load->view('include/footer');
	}

	public function quickSearch($any)
	{	
		
   		$search = str_replace('-', ' ', $any);;
		$title['head'] = 'Search Result';
		$this->load->model('Main_model');
		$data['events'] = $this->Main_model->search($search);
		$data['pages'] = 0;
		$data['tag'] = 'all';
		$data['page'] = -1;
		$this->load->view('include/header', $title);
		$this->load->view('archive', $data);
		$this->load->view('include/footer');
	}
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */