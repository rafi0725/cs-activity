<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
session_start(); //we need to call PHP's session object to access it through CI
class Event extends CI_Controller {
 
 function __construct()
 {
   parent::__construct();
 }
 
 function index()
 {
   if($this->session->userdata('logged_in'))
   {
     $this->load->helper(array('form'));
     $session_data = $this->session->userdata('logged_in');
     
      $data['username'] = $session_data['username'];
      $this->load->model('Event_model');
      $data['events'] = $this->Event_model->lists();
      $title['head'] = 'Events';
      $this->load->view('include/header', $title);
      $this->load->view('event_list', $data);
      $this->load->view('include/footer');
     
   }
   else
   {
     //If no session, redirect to login page
     redirect('login', 'refresh');
   }
 }
 function verify()
 {
   $this->load->library('form_validation');
 
   
   $this->form_validation->set_rules('title', 'Title', 'trim|required|xss_clean|callback_check_database');
   $this->form_validation->set_rules('shortdetails', 'Short Details', 'trim|required|xss_clean');

   if($this->form_validation->run() == FALSE)
   {
     //Field validation failed.  User redirected to login page
     $data['username'] = $session_data['username'];
      $this->load->model('Event_model');
      $data['events'] = $this->Event_model->edit($id);
      $title['head'] = 'Edit Event';
      $this->load->view('include/header', $title);
      $this->load->view('edit_event', $data);
      $this->load->view('include/footer');
   }
   else
   {
     //Go to private area
    redirect('events', 'refresh');
   }
 }
 
 function check_database($title)
 {
   $this->load->model('Event_model','',TRUE);
   //Field validation succeeded.  Validate against database
    $id = $this->input->post('id');
    $title = $this->input->post('title');
    $shortdetails = $this->input->post('shortdetails');
    $tag = $this->input->post('tag');
    $dd = $this->input->post('dd');
    $mm = $this->input->post('mm');
    $yyyy = $this->input->post('yyyy');
    $details = $this->input->post('details');
   //query the database
   
 
   
 
     $this->Event_model->edit_event($id, $title, $shortdetails, $tag, $dd, $mm, $yyyy, $details );
     
     return TRUE;
  
 }
 function delete($id)
 {
    
      $this->load->model('Event_model');
      $this->Event_model->delete($id);
      redirect('events', 'refresh');
 }
 function edit($id)
 {
    
    if($this->session->userdata('logged_in'))
   {
     $this->load->helper(array('form'));
     $session_data = $this->session->userdata('logged_in');
     
      $data['username'] = $session_data['username'];
      $this->load->model('Event_model');
      $data['events'] = $this->Event_model->edit($id);
      
      if($data['events']=='non')
      {
        show_404();
      }
      else
      {
        $title['head'] = 'Edit Event';
        $this->load->view('include/header', $title);
        $this->load->view('edit_event', $data);
        $this->load->view('include/footer');
      }
   }
   else
   {
     //If no session, redirect to login page
     redirect('login', 'refresh');
   }
 }
 
}
 
?>