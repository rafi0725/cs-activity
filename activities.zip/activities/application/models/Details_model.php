<?php
class Details_model extends CI_Model {

        public function __construct()
        {
                $this->load->database();
        }
         public function detail($id)
        {       

                
                $this->db->where("id", $id);
                $sql = $this->db->get('events');
                $result = $sql->result_array();
                
                
                $this->db->select('title');
                $this->db->where("id", $id);
                $title = $this->db->get('events');
                $ti = $title->result_array();
                
                if (empty($result)){ 
                    return array(
                    'result' => 'non',
                    'title' => 'non'
                );
                }
                else {return array(
                    'result' => $result,
                    'title' => $ti
                );}
                

        }
        
}