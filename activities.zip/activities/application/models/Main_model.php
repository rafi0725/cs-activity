<?php
class Main_model extends CI_Model {

        public function __construct()
        {
                $this->load->database();
        }

        public function ten()
        {       
                $this->db->order_by("id", "desc");
        	$sql = $this->db->get('events',10,0);
        	$result = $sql->result_array();
                
        	return $result;

        }
        public function search($search)
        {       
                $this->db->order_by("id", "desc");
                $this->db->like('details', $search);
                $sql = $this->db->get('events');
                $result = $sql->result_array();
                
                return $result;

        }
}