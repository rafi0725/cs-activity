<?php
class Category_model extends CI_Model {

        public function __construct()
        {
                $this->load->database();
        }
         public function all($page)
        {       $start = ($page*5)-5 ; 
                
                $eventnumber = $this->db->count_all_results('events');
                $page_number = $eventnumber/5;
                $page_number = ceil($page_number);

                
                $this->db->order_by("id", "desc");
                $sql = $this->db->get('events',5,$start);
                $result = $sql->result_array();
                
                return array(
                    'result' => $result,
                    'pages' => $page_number,
                );

        }
        public function acc($page)
        {       $start = ($page*5)-5 ; 
                $this->db->where('tag', 'acc');
                $eventnumber = $this->db->count_all_results('events');
                $page_number = $eventnumber/5;
                $page_number = ceil($page_number);

                $this->db->where('tag', 'acc');
                $this->db->order_by("id", "desc");
        	$sql = $this->db->get('events',5,$start);
        	$result = $sql->result_array();
                
        	return array(
                    'result' => $result,
                    'pages' => $page_number,
                );

        }
         public function student($page)
        {       $start = ($page*5)-5 ; 
                $this->db->where('tag', 'student');
                $eventnumber = $this->db->count_all_results('events');
                $page_number = $eventnumber/5;
                $page_number = ceil($page_number);

                $this->db->where('tag', 'student');
                $this->db->order_by("id", "desc");
                $sql = $this->db->get('events',5,$start);
                $result = $sql->result_array();
                
                return array(
                    'result' => $result,
                    'pages' => $page_number,
                );

        }
        public function faculty($page)
        {       $start = ($page*5)-5 ; 
                $this->db->where('tag', 'faculty');
                $eventnumber = $this->db->count_all_results('events');
                $page_number = $eventnumber/5;
                $page_number = ceil($page_number);

                $this->db->where('tag', 'faculty');
                $this->db->order_by("id", "desc");
                $sql = $this->db->get('events',5,$start);
                $result = $sql->result_array();
                
                return array(
                    'result' => $result,
                    'pages' => $page_number,
                );

        }
        public function seminar($page)
        {       $start = ($page*5)-5 ; 
                $this->db->where('tag', 'seminar');
                $eventnumber = $this->db->count_all_results('events');
                $page_number = $eventnumber/5;
                $page_number = ceil($page_number);

                $this->db->where('tag', 'seminar');
                $this->db->order_by("id", "desc");
                $sql = $this->db->get('events',5,$start);
                $result = $sql->result_array();
                
                return array(
                    'result' => $result,
                    'pages' => $page_number,
                );

        }
        public function workshop($page)
        {       $start = ($page*5)-5 ; 
                $this->db->where('tag', 'workshop');
                $eventnumber = $this->db->count_all_results('events');
                $page_number = $eventnumber/5;
                $page_number = ceil($page_number);

                $this->db->where('tag', 'workshop');
                $this->db->order_by("id", "desc");
                $sql = $this->db->get('events',5,$start);
                $result = $sql->result_array();
                
                return array(
                    'result' => $result,
                    'pages' => $page_number,
                );

        }
        public function training($page)
        {       $start = ($page*5)-5 ; 
                $this->db->where('tag', 'training');
                $eventnumber = $this->db->count_all_results('events');
                $page_number = $eventnumber/5;
                $page_number = ceil($page_number);

                $this->db->where('tag', 'training');
                $this->db->order_by("id", "desc");
                $sql = $this->db->get('events',5,$start);
                $result = $sql->result_array();
                
                return array(
                    'result' => $result,
                    'pages' => $page_number,
                );

        }
}