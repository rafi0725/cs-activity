<?php
Class Event_model extends CI_Model
{
 
 
 function addevent($title, $shortdetails, $tag, $dd, $mm, $yyyy, $details )
 {
   
 
    $data = array(
     'title' => $title,
     'short_details' => $shortdetails,
     'tag' => $tag,
     'dd' => $dd,
     'mm' => $mm,
     'yyyy' => $yyyy,
     'details' => $details

    );

    $this->db->insert('events', $data);

    
 }
     function lists()
        {       
            $this->db->order_by("id", "desc");
            $sql = $this->db->get('events');
            $result = $sql->result_array();
                
            return $result;

        }
     function delete($id)
     {
        
          $this->db->where('id', $id);
          $this->db->delete('events'); 
     }
     function edit($id)
        {       
            $this->db->where('id', $id);
            $sql = $this->db->get('events');
            $result = $sql->result_array();
                if (empty($result)){ 

                     $result='non';
                     return $result;
                }
                else {
                    return $result;
                }
            

        }
    function edit_event($id, $title, $shortdetails, $tag, $dd, $mm, $yyyy, $details )
    {
   
 
    $data = array(
     'title' => $title,
     'short_details' => $shortdetails,
     'tag' => $tag,
     'dd' => $dd,
     'mm' => $mm,
     'yyyy' => $yyyy,
     'details' => $details

    );
    
    $this->db->where('id', $id);
    $this->db->update('events', $data); 

    
    }
}
?>