<?php
Class User_model extends CI_Model
{
 function login($username, $password)
 {
   $this->db->select('id, user_name,name,password,access,email');
   $this->db->from('user');
   $this->db->where('user_name', $username);
   $this->db->where('password', MD5($password));
   $this->db->limit(1);
 
   $query = $this->db->get();
  
   if($query->num_rows() == 1)
   {
     return $query->result();
   }
   else
   {
     return false;
   }
 }
 function changepass($username, $password)
 {
   
 
    $data = array(
               'password' => MD5($password)
               
            );

    $this->db->where('user_name', $username);
    $this->db->update('user', $data); 
    
 }
 function validuser($username)
 {
   $this->db->select('id, user_name, password,access');
   $this->db->from('user');
   $this->db->where('user_name', $username);
   $this->db->limit(1);
 
   $query = $this->db->get();
 
   if($query->num_rows() == 1)
   {
     return $query->result();
   }
   else
   {
     return false;
   }
 }
 function createnewuser($name, $username, $email, $password, $access)
 {
   
 
    $data = array(
     'name' => $name,
     'user_name' => $username,
     'password' => MD5($password),
     'access' => $access,
     'email' => $email
    );

    $this->db->insert('user', $data);

    
 }
  public function userslist()
  {       
    $this->db->order_by("id", "desc");
    $sql = $this->db->get('user');
    $result_user = $sql->result_array();
                
    return $result_user;

  }
  function delete($id)
 {
    
      $this->db->where('id', $id);
      $this->db->delete('user'); 
 }
}
?>